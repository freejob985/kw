<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
        <meta name="csrf-token" content="{{csrf_token()}}"> 
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="{{asset('css/font-awesome.min.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('css/custom.css')}}">
   <meta name="user" content="{{Auth::id()}}">
   <meta name="username" content="{{Auth::user()->name}}">
</head>
<body>
<div id="app">
    <div class="col-lg-12">
    <img src="images//logo_k.png" class="logo">
        <div class="chat_box_background">
  <div class="row">
      <div id="private_box" class="privelem prifoff ui-draggable" >
	<div class="top_panel btable top_background ui-draggable-handle" id="private_top">
		<div onclick="" id="private_av_wrap" class="bcell_mid">
			<img id="private_av" src="https://kuwait777.com/avatar/avatar_user15722_1591146188.jpg" onclick="getProfile(15722)">
		</div>
		<div onclick="" id="private_name" class="bcell_mid bellips">@{{privatechatusername}}</div>
		<div id="private_min" onclick="togglePrivate(1);" class="private_opt bcell_mid">
			<i class="fa fa-minus"></i>
		</div>
		<div id="private_close" class="private_opt bcell_mid" @click="hideprivatechat()">
			<i class="fa fa-times"></i>
		</div>
	</div>
	<div id="private_wrap_content">
		<div id="private_content" class="background_box" value="1" v-chat-scroll>
            <div class="large_spinner"><i class="fa fa-spinner fa-spin fa-fw boom_spinner"></i></div>
			<ul >
            <li v-for="(message, index) in privateMessages" :key="index">
						<div class="private_logs" v-if="user == message.parent_id">
							<div class="private_avatar">
								<img data="20181" class="get_info avatar_private" src="https://kuwait777.com/default_images/default_guest.png">
							</div>
							<div class="private_content">
								<div class="hunter_private">@{{message.body}}</div>
							</div>
						</div>
                	<div class="private_logs" v-if="user != message.parent_id">
                        	<div class="private_content">
								<div class="target_private">@{{message.body}}</div>
							</div>
							<div class="private_avatar">
								<img data="20181" class="get_info avatar_private" src="https://kuwait777.com/default_images/default_guest.png">
							</div>
						
						</div>
					</li>
            </ul>
		</div>
		<div id="priv_input_extra" class="add_shadow background_box">
		</div>
	</div>
	<div id="private_input" class="input_wrap">
		<form id="message_form" action="" method="post" name="private_form">
			<div class="input_table">
				<div value="0" id="emo_item_priv" class="input_item main_item" onclick="showPrivEmoticon();">
					<i class="fa fa-smile-o"></i>
				</div>
				<div id="private_input_box" class="td_input">
					<input spellcheck="false"v-model="messageval" id="message_content" placeholder="اكتب هنا..." maxlength="200" autocomplete="off">
				</div>
								<div id="message_send" class="main_item">
					<button class="default_btn csend" v-on:click.prevent="messagecontent()" id="private_send"><i class="fa fa-paper-plane"></i></button>
				</div>
			</div>
		</form>
		</div></div>
   <div class="col-lg-9">
     <messages :messagesarr="childData" :room="room"></messages>
      </div>
   <div class="col-lg-3 ">
       <div class="sidebar_back">
              <ul class="nav nav-tabs" id="myTab" role="tablist">
          <li class="nav-item">
            <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">المستخدمين</a>
          </li>
         
        </ul>
       <rooms @messages="updateMessages" @room="updateRoomid" @private="getPrivateMessages" @privatename="getprivatename" @privateid="getprivateid"></rooms>
      </div>
  </div>
      
      </div>
</div>
           
   <div id="wrap_footer" data="1">
	<div class="chat_footer" id="menu_container">
		<div id="menu_container_inside">
						<div id="player_options" class="player_options sysmenu add_shadow hideall hidden">
								<div class="player_list_container">
					<p class="text_xsmall bold bpad5 rtl_elem">قائمة المحطات</p>
					<div id="player_listing">
						<div class="radio_element sub_list_item" data="https://live.hibridcdn.net/kwmedia/kwfm/playlist.m3u8"><div class="sub_list_name">KuwaitFm -103.7</div></div><div class="radio_element sub_list_item" data="http://31.14.40.102:8006/MarinaFM2090.4.mp3"><div class="sub_list_name">MarinaFM - 90.4</div></div>					</div>
				</div>
								<div class="player_volume">
					<div id="sound_display" class="bcell_mid">
						<i class="fa fa-volume-down show_sound"></i>
					</div>
					<div id="player_volume" class="bcell_mid boom_slider">
						<div id="slider" class="ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"><div class="ui-slider-range ui-corner-all ui-widget-header ui-slider-range-min" style="width: 50%;"></div><span tabindex="0" class="ui-slider-handle ui-corner-all ui-state-default" style="left: 50%;"></span><div class="ui-slider-range ui-corner-all ui-widget-header ui-slider-range-min" style="width: 50%;"></div></div>
					</div>
				</div>
			</div>
						<div id="my_menu">
				<div class="chat_footer_empty bcell_mid">
										<div class="chat_player">
						<div class="player_menu player_elem" onclick="showMenu('player_options');">
							<i class="fa fa-sliders"></i>
						</div>

						<div id="player_actual_status" class="player_elem player_button turn_on_play">
							<i id="current_play_btn" class="fa fa-play-circle"></i>
						</div>
					</div>
									</div>
				<div id="dpriv" onclick="togglePrivate(2);" class="chat_footer_item privhide">
					<img id="dpriv_av" src="">
					<div id="dpriv_notify" class="notification bnotify">
						0
					</div>
				</div>
				<!--<div onclick="toggleRight();" class="chat_footer_item">
					<i class="i_btm fa fa-bars"></i>
				</div>-->
				<div value="0" onclick="getStoriesList();" id="stories_menu" class="privelem chat_footer_item">
					<i class="i_btm fas fa-camera-retro"></i>
					<div>القصص</div>
				</div>
				<div value="0" onclick="getPrivate();" id="get_private" class="privelem chat_footer_item">
					<i class="i_btm fa fa-envelope"></i>
					<div id="notify_private" class="notification bnotify" style="display: none;"></div>
					<div>الخاص</div>
				</div>
				<div id="users_option" title="قائمة المتواجدين" class="chat_footer_item" onclick="userReload(1);">
					<i class="i_btm fa fa-users"></i>
					<div>المتواجدين</div>
				</div>
				<div id="rooms_option" title="قائمة الرومات" class="chat_footer_item" onclick="getRoomList();">
					<i class="i_btm fa fa-home"></i>
					<div>الغرف</div>
				</div>
<!-- -->

<div onclick="showMenu('mobile_main_menu');" id="main_mob_menu">
	<div id="mobile_main_menu" class="sysmenu hideall sub_menu">
			<div class="sub_menu_item" onclick="editProfile();">
				<div class="sub_menu_icon">
					<i class="fa fa-user-circle"></i>
				</div>
				<div class="sub_menu_text">
					ملفي الشخصي				</div>
			</div>
						<div id="room_setting_menu" class="room_granted nogranted sub_menu_item" onclick="getRoomSetting();">
				<div class="sub_menu_icon">
					<i class="fa fa-cog"></i>
				</div>
				<div class="sub_menu_text">
					إعدادات الغرفة				</div>
			</div>
						<div id="open_logout" class="sub_menu_item" onclick="openLogout();">
				<div class="sub_menu_icon">
					<i class="fa fa-sign-out"></i>
				</div>
				<div class="sub_menu_text">
					خروج				</div>
			</div>
		</div>
		<div class="chat_footer_item">
				<img class="avatar_menu glob_av" src="https://kuwait777.com/default_images/default_guest.png">
				<div>الإعدادات</div>
			</div>
	</div>
	<!-- -->
			</div>
		</div>
	</div>
</div>     
    </div>
    </div>
<script src="{{asset('/js/app.js')}}"></script>
<script src="{{asset('/chat_files/custom.js')}}"></script>
    
</body>
</html>
